# 📋 RÉCAP PROJET SITE WEB — STOP GUÊPES FRELONS ET NUISIBLES
*Dernière mise à jour : 19 mai 2026*

---

## 👤 INFORMATIONS CLIENT

| Info | Détail |
|------|--------|
| **Nom** | Christophe Pons |
| **Entreprise** | Stop Guêpes Frelons et Nuisibles |
| **SIREN** | 892 632 738 |
| **Adresse** | 215 Montée des Pierres, 38730 Chélieu |
| **Téléphone** | 06 84 73 52 42 |
| **Email** | sgfnuisibles@gmail.com |
| **Certifications** | Certibiocides + CertiRongeurs |

---

## 🌐 SITE WEB ACTUEL (Local.fr — à remplacer)

| Info | Détail |
|------|--------|
| **URL** | www.stop-guepes-frelons-et-nuisibles.fr |
| **Prestataire** | Local.fr (filiale SoLocal) |
| **Contrat** | N° E-020803 — Code client 213076 |
| **Fin de contrat** | Mars 2027 |
| **Propriétaire domaine** | Local.fr (pas Christophe !) |
| **Contact Local.fr** | m.petre@local.fr |
| **Statut domaine** | Mail envoyé le 19/05/2026 pour rachat |

---

## 🚀 NOUVEAU SITE (en production)

| Info | Détail |
|------|--------|
| **URL temporaire** | https://sgf-nuisibles-site.sgfnuisibles.workers.dev |
| **Hébergement** | Cloudflare Pages (gratuit) |
| **Code source** | GitHub : github.com/sgfnuisibles/sgf-nuisibles-site |
| **Déploiement** | Automatique à chaque push GitHub |

---

## 🏗️ INFRASTRUCTURE TECHNIQUE

| Service | Détail |
|---------|--------|
| **GitHub** | sgfnuisibles/sgf-nuisibles-site |
| **Cloudflare** | sgfnuisibles@gmail.com — Workers & Pages |
| **Supabase** | Projet : pestmanager |
| **Supabase URL** | https://lnisubupgzkprhrctctr.supabase.co |
| **Supabase anon key** | eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... |
| **Table formulaire** | demandes_contact |

---

## 📄 PAGES CRÉÉES (13 pages)

### Pages principales
| Page | Fichier |
|------|---------|
| Accueil | index.html |
| Guêpes & Frelons | guepes-frelons.html |
| Frelon Asiatique | frelons-asiatiques.html |
| Nuisibles & Rongeurs | nuisibles.html |
| Moustiques + Bornes | moustiques.html |

### Pages SEO locales — Villes
| Ville | Fichier |
|-------|---------|
| Bourgoin-Jallieu | destruction-guepes-bourgoin-jallieu.html |
| L'Isle-d'Abeau | destruction-guepes-lisle-abeau.html |
| La Tour-du-Pin | destruction-guepes-la-tour-du-pin.html |
| Voiron | destruction-guepes-voiron.html |
| Villefontaine | destruction-guepes-villefontaine.html |

### Pages SEO locales — Intercommunalités
| Territoire | Fichier |
|------------|---------|
| Vals du Dauphiné | destruction-guepes-vals-du-dauphine.html |
| Balcons du Dauphiné | destruction-guepes-balcons-du-dauphine.html |
| Pays Voironnais | destruction-guepes-pays-voironnais.html |

---

## 🎨 CHARTE GRAPHIQUE

| Élément | Valeur |
|---------|--------|
| **Vert principal** | #267326 |
| **Rouge urgence** | #C8102E |
| **Police titres** | Oswald |
| **Police texte** | Open Sans |
| **Logo** | Encodé en base64 dans chaque page |

---

## ✅ FONCTIONNALITÉS EN PLACE

- [x] Site en ligne sur Cloudflare
- [x] Logo intégré sur toutes les pages
- [x] Formulaire de contact fonctionnel
- [x] Connexion Supabase — demandes dans table `demandes_contact`
- [x] SEO optimisé (title, meta, Schema.org) sur chaque page
- [x] Responsive mobile
- [x] Numéro de téléphone cliquable partout
- [x] Champ email optionnel dans le formulaire
- [x] Page Moustiques avec offre bornes (vente/location/maintenance)

---

## 🔧 À FAIRE (priorités)

### Priorité 1 — Domaine
- [ ] Attendre réponse de m.petre@local.fr pour rachat domaine
- [ ] Si OK : transférer domaine vers Cloudflare
- [ ] Si refus : enregistrer nouveau domaine chez OVH (~10€/an)

### Priorité 2 — Notification push
- [ ] Connecter les demandes Supabase à l'app SGF Nuisibles
- [ ] Notification push quand une nouvelle demande arrive

### Priorité 3 — SEO
- [ ] Créer ~20 pages communes secondaires (Morestel, Dolomieu, Les Abrets, Pont-de-Beauvoisin, Virieu, etc.)
- [ ] Page Actualités (articles saisonniers)
- [ ] Inscrire le site sur Google Search Console
- [ ] Créer/mettre à jour Google Business Profile

### Priorité 4 — Contenu
- [ ] Photos locales par ville dans les pages hero
- [ ] Mentions légales
- [ ] Page Contact dédiée

### Priorité 5 — Évolutions futures
- [ ] Photos de chaque ville dans le hero
- [ ] Carte interactive de la zone d'intervention
- [ ] Blog/Actualités saisonnières

---

## 📞 CONTACTS UTILES

| Service | Contact |
|---------|---------|
| **Local.fr** | m.petre@local.fr — 04 74 50 41 55 |
| **OVH** (domaine) | 1007 (gratuit) |
| **AFNIC** (litiges domaine) | afnic.fr |

---

## 💡 NOTES IMPORTANTES

1. **Le domaine appartient à Local.fr** — c'est le point critique. Sans lui, le SEO capitalisé est perdu en mars 2027.

2. **Le nouveau site est MIEUX optimisé SEO** que l'actuel — Schema.org, pages par ville/intercommunalité, contenu enrichi.

3. **Cloudflare redéploie automatiquement** à chaque upload sur GitHub — pas besoin de toucher à Cloudflare après chaque modification.

4. **Les demandes formulaire** arrivent dans Supabase → table `demandes_contact`. Vérifiable depuis le Table Editor.

5. **La saison des guêpes** commence en mai — le site est en ligne au bon moment !

---

## 🔔 NOTIFICATIONS PUSH — Session du 20 mai 2026

### OneSignal configuré
| Info | Détail |
|------|--------|
| **App ID** | c92298e7-8f64-487b-8e03-4d7b284c7f50 |
| **API Key** | os_v2_app_zerjrz4pmrehxdqdjv5sqtd7kdgrcrcvsame6mnhzju2abjpepbgczbikdvfudupj5trvvtdnwe2z6u256w5eu6ff54kou7ezcj4auq |
| **Plan** | Free |

### Infrastructure notifications
- ✅ Edge Function Supabase : `notify-demande`
- ✅ Webhook Supabase : `notify-nouvelle-demande` sur table `demandes_contact` (INSERT)
- ✅ OneSignal Web Push intégré sur les 13 pages
- ✅ Fichier `OneSignalSDKWorker.js` uploadé sur GitHub
- ✅ Notifications reçues sur iPhone (site ajouté à l'écran d'accueil)

### Parcours d'une demande client
1. Client remplit formulaire → Supabase `demandes_contact`
2. Webhook déclenche Edge Function `notify-demande`
3. Edge Function appelle OneSignal API
4. Notification push reçue sur iPhone avec nom, commune, téléphone

### À faire prochaine session
- [ ] Email automatique sur sgfnuisibles@gmail.com avec tous les détails client
- [ ] Améliorer le contenu visible de la notification push
- [ ] Lien depuis la notification vers les détails de la demande

---

## 🆕 Session du 12 novembre 2026 — Extension du site

- ✅ 3 nouvelles pages : `punaises-de-lit.html`, `cafards.html`, `contrats-annuels.html` (accent sur contrats annuels pro : restaurants, entreprises, collectivités, hébergeurs, résidences)
- ✅ Accueil : 2 nouvelles cartes services, bandeau vert « Contrats pro », 3e bouton hero
- ✅ Navigation mise à jour sur les 16 pages (lien « Actualités » retiré car page inexistante)
- ✅ CORRECTIF : les formulaires des 12 pages intérieures n'étaient PAS reliés à Supabase (faux bouton « Envoyé »). Maintenant tous envoient dans `demandes_contact` (testé en simulation sur les 16 pages)
- ✅ Logo allégé (800 Ko → 10 Ko par page)
- ✅ Pastilles « communes proches » : liens vers pages inexistantes corrigés

### À vérifier / décider
- [ ] Hypothèses de contenu à valider : rapport écrit à chaque passage, fréquences mensuelle/bimestrielle/trimestrielle, second passage punaises quelques semaines après
- [ ] Engagements rédigés sans validation : « retour gratuit si nid non éliminé », « intervention le jour même » (pages existantes)
- [ ] Page Mentions légales (obligatoire, lien cassé sur toutes les pages)
- [ ] Page Actualités, pages communes secondaires
- [ ] Contrat Local.fr : vérifier si résiliation envoyée en LRAR (préavis 3 mois avant échéance mars/avril 2027)
